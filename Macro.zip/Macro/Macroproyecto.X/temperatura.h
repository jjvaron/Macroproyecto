/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef TEMPERATURA_MCP9808_H
#define TEMPERATURA_MCP9808_H


#include <xc.h>
#include <stdio.h>

typedef struct temp_T temp_T;
struct temp_T
{
    uint8_t tempValor;
    char bandera_exito;
    char bandera_error;
};

void temp_Configuracion(temp_T *t);
uint8_t temp_LecturaCelsius(temp_T *t);

#endif /* TEMPERATURA_MCP9808_H */

