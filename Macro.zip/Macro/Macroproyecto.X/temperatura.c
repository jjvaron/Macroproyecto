/*
 * File:   temperatura.c
 * Author: estudiante
 *
 * Created on November 28, 2020, 9:56 AM
 */

#include "temperatura.h"
 